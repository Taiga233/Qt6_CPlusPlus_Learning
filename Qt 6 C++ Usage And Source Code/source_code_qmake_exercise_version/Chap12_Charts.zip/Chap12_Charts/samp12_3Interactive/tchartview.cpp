#include "tchartview.h"

TChartView::TChartView(QWidget *parent):QChartView(parent)
{
}

TChartView::~TChartView()
{

}
