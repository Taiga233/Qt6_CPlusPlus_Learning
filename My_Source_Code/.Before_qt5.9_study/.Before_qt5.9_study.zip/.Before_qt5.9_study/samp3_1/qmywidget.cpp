#include "qmywidget.h"
#include "ui_qmywidget.h"
#include <QTableWidgetSelectionRange>

QmyWidget::QmyWidget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::QmyWidget)
{
    ui->setupUi(this);
    //构造函数

    boy = new QPerson("taiga");
    boy->setProperty("age", 16); //设置头文件中定义了的属性
//    boy->setProperty("name", "taiga");
    boy->setProperty("score", 95); //设置头文件中定义了的属性
    boy->setProperty("sex", "male"); ///动态属性
    //使用函数指针的方式关联on_ageChanged槽函数
    //因为QPerson只有一个ageChanged()信号，具有缺省函数参数，所以这样设置关联是可以的；
    connect(boy, &QPerson::ageChanged, this, &QmyWidget::on_ageChanged);

    girl = new QPerson("lala");
    girl->setProperty("age", 15);
    girl->setProperty("score", 100);
    girl->setProperty("sex", "female");
    connect(girl, &QPerson::ageChanged, this, &QmyWidget::on_ageChanged);

    //为界面上的组件boy_spinBox、girl_spinBox也设置一个逻辑型的动态属性isBoy；
    ui->boy_spinBox->setProperty("isBoy", true);
    ui->boy_spinBox->setValue(boy->property("age").toInt());
    ui->girl_spinBox->setProperty("isBoy", false);
    ui->girl_spinBox->setValue(girl->property("age").toInt());
    ///这里使用connect()函数设置关联时，必须使用SIGNAL和SLOT宏的形式，而不能使用指针的形式；
    ///因为QSpinBox有两个valueChanged()信号，只是参数不同；
    connect(ui->boy_spinBox, SIGNAL(valueChanged(int)), this, SLOT(on_spin_valueChanged(int)));
    connect(ui->girl_spinBox, SIGNAL(valueChanged(int)), this, SLOT(on_spin_valueChanged(int)));
}

QmyWidget::~QmyWidget()
{
    delete ui;
}

//响应QPerson的on_ageChanged()信号
void QmyWidget::on_ageChanged(int value)
{
    ///Q_UNUSED() 没有实质性的作用，用来避免编译器警告
    Q_UNUSED(value);
    QPerson *a_person = qobject_cast<QPerson *>(sender()); //类型投射
    QString person_name = a_person->property("name").toString();
    QString person_sex = a_person->property("sex").toString(); //动态属性
    int person_age = a_person->getAge(); //通过接口获取年龄
    //int person_age = a_person->property("age").toInt(); //通过属性获取年龄
    ui->plainTextEdit->appendPlainText(person_name + "," + person_sex
                                       + QString::asprintf(",年龄 = %d", person_age));
    //设置一下boy/girl的spinBox随之变化
    if (a_person->property("sex").toString() == "male") {
        ui->boy_spinBox->setValue(value);
    } else {
        ui->girl_spinBox->setValue(value);
    }
}

//响应界面上boy_spinBox、girl_spinBox的valueChanged(int)信号
void QmyWidget::on_spin_valueChanged(int parameter)
{
    ///Q_UNUSED() 没有实质性的作用，用来避免编译器警告
    Q_UNUSED(parameter);
    ///使用了信号发射者的类型投射
    QSpinBox *spinbox = qobject_cast<QSpinBox *>(sender()); //获取信号的发射者
    if (spinbox->property("isBoy").toBool()) {
        boy->setAge(spinbox->value());
    } else {
        girl->setAge(spinbox->value());
    }
}

//按下boy长大一岁的槽函数
void QmyWidget::on_boy_add_one_btn_clicked()
{
    boy->age_add_one();
}

//按下girl长大一岁的槽函数
void QmyWidget::on_girl_add_one_btn_clicked()
{
    girl->age_add_one();
}

//“类的元对象信息”按钮
void QmyWidget::on_class_meta_info_btn_clicked()
{
    //boy information
    const QMetaObject *meta_boy = boy->metaObject();
    ui->plainTextEdit->clear(); //先清空编辑区
    ui->plainTextEdit->appendPlainText(
                QString("\t\tboy's information:\n类名称：%1").arg(meta_boy->className())); //获取类名
    ui->plainTextEdit->appendPlainText("property:"); //调用appendPlainText末尾会自动换行
    //利用循环追加信息：
    for (int i = meta_boy->propertyOffset(); i < meta_boy->propertyCount(); i++) {
        QMetaProperty meta_property = meta_boy->property(i); //需要引入头文件<QMetaProperty>
        const char *meta_property_name = meta_property.name();
        QString meta_property_boy_value = boy->property(meta_property_name).toString();
        ui->plainTextEdit->appendPlainText(
                    QString("属性名称：%1，boy属性值：%2;").arg(meta_property_name)
                    .arg(meta_property_boy_value));
    }
//    ui->plainTextEdit->appendPlainText(""); //相当于换行
//    ui->plainTextEdit->appendPlainText("classInfo");
//    for (int i = meta_boy->classInfoOffset(); i < meta_boy->classInfoCount(); i++) {
//        QMetaClassInfo class_info = meta_boy->classInfo(i);
//        ui->plainTextEdit->appendPlainText(
//                    QString("Name = %1; Value = %2").arg(class_info.name()).arg(class_info.value()));
//    }

    //girl information
    const QMetaObject *meta_girl = girl->metaObject();
//    ui->plainTextEdit->clear(); //girl就不清空了
    ui->plainTextEdit->appendPlainText("");
    ui->plainTextEdit->appendPlainText(
                QString("\t\tgirl's information:\n类名称：%1").arg(meta_girl->className())); //获取类名
    ui->plainTextEdit->appendPlainText("property:"); //调用appendPlainText末尾会自动换行
    //利用循环追加信息：
    for (int i = meta_girl->propertyOffset(); i < meta_girl->propertyCount(); i++) {
        QMetaProperty meta_property = meta_girl->property(i); //需要引入头文件<QMetaProperty>
        const char *meta_property_name = meta_property.name();
        QString meta_property_girl_value = girl->property(meta_property_name).toString();
        ui->plainTextEdit->appendPlainText(
                    QString("属性名称：%1，girl属性值：%2;").arg(meta_property_name)
                    .arg(meta_property_girl_value));
    }
    ui->plainTextEdit->appendPlainText(""); //相当于换行
    ui->plainTextEdit->appendPlainText("classInfo");
    for (int i = meta_girl->classInfoOffset(); i < meta_girl->classInfoCount(); i++) {
        QMetaClassInfo class_info = meta_girl->classInfo(i);
        ui->plainTextEdit->appendPlainText(
                    QString("Name = %1; Value = %2").arg(class_info.name()).arg(class_info.value()));
    }
}

//按下“清空文本框”按钮响应的槽函数
void QmyWidget::on_clear_text_edit_btn_clicked()
{
    ui->plainTextEdit->clear();
}

