#ifndef QPERSON_H
#define QPERSON_H

#include <QObject>

class QPerson : public QObject
{
    //未设置成员类型的默认未私有的
    Q_OBJECT
    //附加信息
    Q_CLASSINFO("author", "pengyirong")
    Q_CLASSINFO("company", "ZM")
    Q_CLASSINFO("version", "1.0.0")
    //定义属性，类型为int；
    //指定age()函数为读取属性值的函数；
    //指定setAge()函数为设定属性值的函数，当属性为只读的时候没有WRITE设置；
    //ageChanged信号是可选的(NOTIFY)，当属性值变化时发射该信号；
    Q_PROPERTY(int age READ getAge WRITE setAge NOTIFY ageChanged)
    //定义了name和score两个属性，将成员变量my_name、my_score设置为可读可写属性，无需再设置READ和WRITE；
    Q_PROPERTY(QString name MEMBER my_name)
    Q_PROPERTY(int score MEMBER my_score)

private:
    int my_age = 10;
    QString my_name;
    int my_score = 79;

public:
    explicit QPerson(QString Name, QObject *parent = nullptr);
    int getAge();
    void setAge(int value);
    void age_add_one();
//    自动创建的构造函数给屏蔽掉
//    ~QPerson();

signals:
    void ageChanged(int value);

public slots:

};

#endif // QPERSON_H
