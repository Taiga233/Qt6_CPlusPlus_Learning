#include "qperson.h"

QPerson::QPerson(QString Name, QObject *parent) : QObject(parent)
{
    my_name = Name;
}

int QPerson::getAge()
{
    return my_age;
}

void QPerson::setAge(int value)
{
    my_age = value;
    emit ageChanged(my_age);
}

void QPerson::age_add_one()
{
    my_age++;
    emit ageChanged(my_age); //emit ageChange(++my_age);
}

