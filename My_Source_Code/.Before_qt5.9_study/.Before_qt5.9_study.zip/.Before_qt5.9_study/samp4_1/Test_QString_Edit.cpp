#include "Test_QString_Edit.h"
#include "ui_Test_QString_Edit.h"
#include <QDebug>

TestQStringToNumber_Edit::TestQStringToNumber_Edit(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::TestQStringToNumber_Edit)
{
    ui->setupUi(this);
}

TestQStringToNumber_Edit::~TestQStringToNumber_Edit()
{
    delete ui;
}

void TestQStringToNumber_Edit::on_calculation_pushButton_clicked()
{
    QString str_cnt = ui->count_lineEdit->text();
    int num = str_cnt.toInt();
    QString str_price = ui->price_lineEdit->text();
    float price = str_price.toFloat();
    float total = price * num;
    ui->total_price_lineEdit->setText(str_cnt.asprintf("%.2f", total));
}

void TestQStringToNumber_Edit::on_conversion_pushButton_1_clicked()
{
    //读取十进制的lineEdit转换为其他进制数
    QString str_Deci = ui->Deci_lineEdit->text();

    //十进制
    int val_Deci = str_Deci.toInt(); //缺省为十进制
//    QString str_Hex_converted = QString::number(val_Deci, 16); //使用静态函数
    QString str_Hex_converted = str_Deci.setNum(val_Deci, 16); //使用共有成员函数
    str_Hex_converted = str_Hex_converted.toUpper(); //全部字母大写
    ui->Hex_lineEdit->setText(str_Hex_converted);

    //二进制
    QString str_Bin_converted = QString::number(val_Deci, 2);
//    QString str_Bin_converted = str_Deci.setNum(val_Deci, 2);
    ui->Bin_lineEdit->setText(str_Bin_converted);
}

void TestQStringToNumber_Edit::on_conversion_pushButton_2_clicked()
{
    QString str_Bin = ui->Bin_lineEdit->text();
    ///qDebug() << "str_Bin before: " << str_Bin;
    //ui->Deci_lineEdit->setText(str_Bin.setNum(str_Bin.toInt(NULL, 2))); //不在乎转换是否失败
    ///qDebug() << "str_Bin after: " << str_Bin;
    //setNum返回的是引用，会改变str_Bin的值，所以不能这样用；
    ui->Deci_lineEdit->setText(QString::number(str_Bin.toInt(NULL, 2)));
    ui->Hex_lineEdit->setText(QString::number(str_Bin.toInt(NULL, 2), 16).toUpper());
}

void TestQStringToNumber_Edit::on_conversion_pushButton_3_clicked()
{
    QString str_Hex = ui->Hex_lineEdit->text();
    //!!!引用会改变值，所以最好不要这样用
    //ui->Deci_lineEdit->setText(str_Hex.setNum(str_Hex.toInt(NULL, 16)));
    //ui->Bin_lineEdit->setText(str_Hex.setNum(str_Hex.toInt(NULL, 16), 2));
    ui->Deci_lineEdit->setText(QString::number(str_Hex.toInt(NULL, 16)));
    ui->Bin_lineEdit->setText(QString::number(str_Hex.toInt(NULL, 16), 2));
}
