#include "Test_QString_Edit.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    TestQStringToNumber_Edit w;
    w.show();
    return a.exec();
}
