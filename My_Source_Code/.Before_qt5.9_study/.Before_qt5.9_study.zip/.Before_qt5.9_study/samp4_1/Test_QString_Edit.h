#ifndef TESTQSTRINGTONUMBER_EDIT_H
#define TESTQSTRINGTONUMBER_EDIT_H

#include <QWidget>

QT_BEGIN_NAMESPACE
namespace Ui { class TestQStringToNumber_Edit; }
QT_END_NAMESPACE

class TestQStringToNumber_Edit : public QWidget
{
    Q_OBJECT

public:
    TestQStringToNumber_Edit(QWidget *parent = nullptr);
    ~TestQStringToNumber_Edit();

private slots:
    void on_calculation_pushButton_clicked();

    void on_conversion_pushButton_1_clicked();

    void on_conversion_pushButton_2_clicked();

    void on_conversion_pushButton_3_clicked();

private:
    Ui::TestQStringToNumber_Edit *ui;
};
#endif // TESTQSTRINGTONUMBER_EDIT_H
