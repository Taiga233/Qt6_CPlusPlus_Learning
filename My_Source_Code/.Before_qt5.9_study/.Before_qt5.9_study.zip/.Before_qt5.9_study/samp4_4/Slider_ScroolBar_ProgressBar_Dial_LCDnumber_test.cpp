#include "Slider_ScroolBar_ProgressBar_Dial_LCDnumber_test.h"
#include "ui_Slider_ScroolBar_ProgressBar_Dial_LCDnumber_test.h"

Slider_test::Slider_test(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Slider_test)
{
    ui->setupUi(this);
    //其他三个滑动条的响应代码与红色的一样，不需要另外写代码，
    //只需要在窗口类的构造函数里面将他们的valueChanged(int)信号与红色滑动条的槽函数关联即可；
    //这里只需关联一个
    QObject::connect(ui->horizontalSlider_04_alpha, SIGNAL(valueChanged(int)),
                     this, SLOT(on_horizontalSlider_01_red_valueChanged(int)));
}

Slider_test::~Slider_test()
{
    delete ui;
}

//拖动Red、Green、Blue颜色滑动条设置TextEdit的底色槽函数
void Slider_test::on_horizontalSlider_01_red_valueChanged(int value)
{
    Q_UNUSED(value);
    QColor color;
    color.setRgb(ui->horizontalSlider_01_red->value(), ui->horizontalSlider_02_green->value(),
                 ui->horizontalSlider_03_blue->value(), ui->horizontalSlider_04_alpha->value());
    //还是先获取后设置调色板(背景色)
    QPalette text_edit_palette = ui->textEdit_01_color->palette();
    text_edit_palette.setColor(QPalette::Base, color); //设置底色
    ui->textEdit_01_color->setPalette(text_edit_palette);
}

void Slider_test::on_horizontalSlider_02_green_valueChanged(int value)
{
    on_horizontalSlider_01_red_valueChanged(value);
}

void Slider_test::on_horizontalSlider_03_blue_valueChanged(int value)
{
    on_horizontalSlider_01_red_valueChanged(value);
}

void Slider_test::on_dial_01_ticks_valueChanged(int value)
{
    //设置当dial改变的时候，设置LCD的值等于dial的值
    ui->lcdNumber_01_max127->display(value);
}

void Slider_test::on_radioButton_01_Dec_clicked()
{
    //设置LCD显示十进制的数
    ui->lcdNumber_01_max127->setDigitCount(3); //设置LCD显示的位数
    ui->lcdNumber_01_max127->setDecMode(); //设置成十进制模式
}

void Slider_test::on_radioButton_02_Bin_clicked()
{
    //设置LCD显示二进制的数
    ui->lcdNumber_01_max127->setDigitCount(8);
    ui->lcdNumber_01_max127->setBinMode(); //设置成二进制模式
}

void Slider_test::on_radioButton_03_Oct_clicked()
{
    //设置LCD显示八进制的数
    ui->lcdNumber_01_max127->setDigitCount(4);
    ui->lcdNumber_01_max127->setOctMode(); //设置成八进制模式
}

void Slider_test::on_radioButton_04_Hex_clicked()
{
    //设置LCD显示十六进制的数
    ui->lcdNumber_01_max127->setDigitCount(3);
    ui->lcdNumber_01_max127->setHexMode(); //设置成十六进制模式
}
