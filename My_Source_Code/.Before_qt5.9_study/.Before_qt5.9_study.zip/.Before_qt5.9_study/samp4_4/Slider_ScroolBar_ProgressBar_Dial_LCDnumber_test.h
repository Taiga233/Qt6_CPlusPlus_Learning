#ifndef SLIDER_TEST_H
#define SLIDER_TEST_H

#include <QWidget>

QT_BEGIN_NAMESPACE
namespace Ui { class Slider_test; }
QT_END_NAMESPACE

class Slider_test : public QWidget
{
    Q_OBJECT

public:
    Slider_test(QWidget *parent = nullptr);
    ~Slider_test();

private slots:
    void on_horizontalSlider_01_red_valueChanged(int value);

    void on_horizontalSlider_02_green_valueChanged(int value);

    void on_horizontalSlider_03_blue_valueChanged(int value);

    void on_dial_01_ticks_valueChanged(int value);

    void on_radioButton_01_Dec_clicked();

    void on_radioButton_02_Bin_clicked();

    void on_radioButton_03_Oct_clicked();

    void on_radioButton_04_Hex_clicked();

private:
    Ui::Slider_test *ui;
};
#endif // SLIDER_TEST_H
