#include "Slider_ScroolBar_ProgressBar_Dial_LCDnumber_test.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Slider_test w;
    w.show();
    return a.exec();
}
