#include "dialog.h"
#include "ui_dialog.h"

Dialog::Dialog(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::Dialog)
{
    ui->setupUi(this);

    /* 由于这个槽函数是自定义的，所以不会自动与 RadioButton 的 clicked() 事件关联，
     * 此时编译后运行程序不会实现改变字体颜色的功能。
     * 需要在 QWDialog 的构造函数中手工进行关联
     * 代码如下：
     */
    connect(ui->radioButtonBule, SIGNAL(clicked()), this, SLOT(setTextFontColor()));
    connect(ui->radioButtonRed, SIGNAL(clicked()), this, SLOT(setTextFontColor()));
    connect(ui->radioButtonBlack, SIGNAL(clicked()), this, SLOT(setTextFontColor()));
    /* 在构造函数中将 3 个 RadioButton 的 clicked() 信号与同一个槽函数 setTextFontColor() 相关联。
     * 再编译后运行，就可以更改文字的颜色了。
     */
}

Dialog::~Dialog()
{
    delete ui;
}


void Dialog::on_checkBoxUnder_clicked(bool checked)
{
    QFont font = ui->plainTextEdit->font();
    font.setUnderline(checked);
    ui->plainTextEdit->setFont(font);
}

void Dialog::on_checkBoxItalic_clicked(bool checked)
{
    QFont font = ui->plainTextEdit->font();
    font.setItalic(checked);
    ui->plainTextEdit->setFont(font);
}

void Dialog::on_checkBoxBold_clicked(bool checked)
{
    QFont font = ui->plainTextEdit->font();
    font.setBold(checked);
    ui->plainTextEdit->setFont(font);

}

//根据自动生成的设置关联textEdit颜色的槽函数
//手动补充完全代码（设置颜色）
void Dialog::setTextFontColor()
{
    QPalette plet = ui->plainTextEdit->palette();
    if (ui->radioButtonBule->isChecked())
        plet.setColor(QPalette::Text, Qt::blue);
    else if (ui->radioButtonRed->isChecked())
        plet.setColor(QPalette::Text, Qt::red);
    else if (ui->radioButtonBlack->isChecked())
        plet.setColor(QPalette::Text, Qt::black);
    else
        plet.setColor(QPalette::Text, Qt::black);
    ui->plainTextEdit->setPalette(plet);
}
