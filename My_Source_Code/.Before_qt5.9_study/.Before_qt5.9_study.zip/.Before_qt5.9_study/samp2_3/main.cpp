#include "my_qt_widget_dialog_manual.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    My_Qt_Widget_Dialog_Manual w;
    w.show();
    return a.exec();
}
