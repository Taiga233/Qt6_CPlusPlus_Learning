#ifndef MY_QT_WIDGET_DIALOG_MANUAL_H
#define MY_QT_WIDGET_DIALOG_MANUAL_H

#include <QDialog>
#include <QCheckBox> //check box
#include <QRadioButton> //radio button
#include <QPlainTextEdit> //plain text edit
#include <QPushButton> //push button
#include <QHBoxLayout> //QHBoxLayout
#include <QVBoxLayout> //QVBoxLayout

class My_Qt_Widget_Dialog_Manual : public QDialog
{
    //使用Q_OBJECT宏
    //这是使用Qt信号与槽机制的类都必须加入的一个宏
    Q_OBJECT

public:
    My_Qt_Widget_Dialog_Manual(QWidget *parent = nullptr);
    ~My_Qt_Widget_Dialog_Manual();

private:
    QCheckBox *chkBoxUnder; //声明一个设置文本有无下划线的check box
    QCheckBox *chkBoxItalic; //声明一个设置文本有无斜体的check box
    QCheckBox *chkBoxBold; //声明一个设置文本有无加粗的check box

    QRadioButton *rBtnBlack; //声明一个设置文本为黑色的radio button
    QRadioButton *rBtnRed; //声明一个设置文本为红色的radio button
    QRadioButton *rBtnBlue; //声明一个设置文本为蓝色的radio button

    QPlainTextEdit *txtEdit; //声明一个文本编辑plain text edit

    QPushButton *btnOK; //三个按钮分别为：确定、取消、退出
    QPushButton *btnCancel;
    QPushButton *btnClose;

    void initUI(); //声明一个UI创建和初始化的函数
    void initSignalSlots(); //声明一个初始化信号与槽的链接（接口）

private slots:
    void on_chkBoxUnder(bool checked); //underline 的槽函数
    void on_chkBoxItalic(bool checked); //italic 的槽函数
    void on_chkBoxBold(bool checked); //bold 的槽函数

    void setTextFontColor(); //设置字体颜色的槽函数
};

#endif // MY_QT_WIDGET_DIALOG_MANUAL_H
