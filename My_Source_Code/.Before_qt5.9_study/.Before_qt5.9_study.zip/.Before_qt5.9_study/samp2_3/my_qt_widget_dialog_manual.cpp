#include "my_qt_widget_dialog_manual.h"

My_Qt_Widget_Dialog_Manual::My_Qt_Widget_Dialog_Manual(QWidget *parent)
    : QDialog(parent)
{
    initUI(); //界面的创建与布局的初始化函数
    initSignalSlots(); //信号与槽关联的初始化函数

    setWindowTitle("Form created manualy"); //设置窗口体的标题
    //这里默认为项目文件夹名称
}

My_Qt_Widget_Dialog_Manual::~My_Qt_Widget_Dialog_Manual()
{
}

void My_Qt_Widget_Dialog_Manual::on_chkBoxUnder(bool checked)
{
    QFont font = txtEdit->font();
    font.setUnderline(checked); //给临时的font对象设置下划线属性
    txtEdit->setFont(font); //给txtEdit设置字体为font
}

void My_Qt_Widget_Dialog_Manual::on_chkBoxItalic(bool checked)
{
    QFont font = txtEdit->font();
    font.setItalic(checked); //给临时的font对象设置斜体属性
    txtEdit->setFont(font);
}

void My_Qt_Widget_Dialog_Manual::on_chkBoxBold(bool checked)
{
    QFont font = txtEdit->font(); //给临时的font对象设置加粗属性
    font.setBold(checked);
    txtEdit->setFont(font);
}

//互斥设置字体颜色的槽函数
void My_Qt_Widget_Dialog_Manual::setTextFontColor()
{
    QPalette txtEdit_palette = txtEdit->palette(); //定义调色板对象（拿出来用）
    if (rBtnRed->isChecked()) {
        txtEdit_palette.setColor(QPalette::Text, Qt::red);
    } else if (rBtnBlue->isChecked()) {
        txtEdit_palette.setColor(QPalette::Text, Qt::blue);
    } else if (rBtnBlack->isChecked()) {
        txtEdit_palette.setColor(QPalette::Text, Qt::black);
    } else {
        txtEdit_palette.setColor(QPalette::Text, Qt::black);
    }
    //设置好颜色了之后放回去
    txtEdit->setPalette(txtEdit_palette); //设置txtEdit文本框对象的调色板属性
}

void My_Qt_Widget_Dialog_Manual::initUI()
{
    //创建underlin、italic、bold三个CheckBox，并水平布局
    chkBoxUnder = new QCheckBox(tr("Underline"));
    chkBoxItalic = new QCheckBox(tr("Italic"));
    chkBoxBold = new QCheckBox(tr("Bold"));
    //new一个水平布局对象
    QHBoxLayout *Hlayout_1 = new QHBoxLayout;
    //将三个CheckBox加入到水平布局对象中；
    Hlayout_1->addWidget(chkBoxUnder);
    Hlayout_1->addWidget(chkBoxItalic);
    Hlayout_1->addWidget(chkBoxBold);

    //创建Black、Red、Blue三个RadioButton，并水平布局
    rBtnBlack = new QRadioButton(tr("Black"));
    rBtnBlack->setChecked(true); //相当于默认选中这个单选按钮
    rBtnRed = new QRadioButton(tr("Red"));
    //rBtnRed->setChecked(true); //只是一个默认选中的状态，但是没有设置颜色
    //因为还没有单击（发出clicked()信号）
    //如果多次设置可以同时显示出被选中状态，这也是单选按钮的一个小bug
    rBtnBlue = new QRadioButton(tr("Blud"));
    //new一个水平布局对象
    QHBoxLayout *Hlayout_2 = new QHBoxLayout;
    //将三个RadioButton加入到水平布局对象中；
    Hlayout_2->addWidget(rBtnBlack);
    Hlayout_2->addWidget(rBtnRed);
    Hlayout_2->addWidget(rBtnBlue);

    //创建 确定、取消、退出 三个PushButton，并水平布局
    btnOK = new QPushButton(tr("确定"));
    btnCancel = new QPushButton(tr("取消"));
    btnClose = new QPushButton(tr("退出"));
    //new一个水平布局对象
    QHBoxLayout *Hlayout_3 = new QHBoxLayout;
    //将三个PushButton加入到水平布局对象中；
    Hlayout_3->addStretch(); //加一个水平的空Stretch；
    Hlayout_3->addWidget(btnOK);
    Hlayout_3->addWidget(btnCancel);
    Hlayout_3->addStretch();
    Hlayout_3->addWidget(btnClose);

    //创建 文本框 ，并设置字体
    txtEdit = new QPlainTextEdit("Hello World\n\nIt's my demo");
    QFont font = txtEdit->font(); //获取字体对象
    font.setPointSize(20); //设置字体大小为20像素
    txtEdit->setFont(font); //设置字体

    //创建垂直布局，并设置为主布局
    QVBoxLayout *Vlayout_main = new QVBoxLayout;
    Vlayout_main->addLayout(Hlayout_1); //添加字体类型组布局
    Vlayout_main->addLayout(Hlayout_2); //添加单选按钮类型组布局
    Vlayout_main->addWidget(txtEdit); //添加 PlainTextEdit 文本框
    Vlayout_main->addLayout(Hlayout_3); //添加按键类型组布局
    //设置该布局为窗体的主布局
    //setLayout(Vlayout_main);
    My_Qt_Widget_Dialog_Manual::setLayout(Vlayout_main);
}

void My_Qt_Widget_Dialog_Manual::initSignalSlots()
{
    //三个控制颜色的RadioButton的clicked()信号与setTextFontColor()槽函数关联
    connect(rBtnRed, SIGNAL(clicked()), this, SLOT(setTextFontColor()));
    connect(rBtnBlue, SIGNAL(clicked()), this, SLOT(setTextFontColor()));
    connect(rBtnBlack, SIGNAL(clicked()), this, SLOT(setTextFontColor()));

    //三个字体设置的 QCheckBox 的 clicked(bool) 信号与对应的槽函数关联
    connect(chkBoxUnder, SIGNAL(clicked(bool)), this, SLOT(on_chkBoxUnder(bool)));
    connect(chkBoxItalic, SIGNAL(clicked(bool)), this, SLOT(on_chkBoxItalic(bool)));
    connect(chkBoxBold, SIGNAL(clicked(bool)), this, SLOT(on_chkBoxBold(bool)));

    //三个按钮的信号与窗体的槽函数关联
    connect(btnOK, SIGNAL(clicked()), this, SLOT(accept())); //确认的槽函数
    connect(btnCancel, SIGNAL(clicked()), this, SLOT(reject())); //取消的槽函数
    connect(btnClose, SIGNAL(clicked()), this, SLOT(close())); //关闭的槽函数
}
