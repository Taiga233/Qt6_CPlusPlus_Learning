#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_clicked()
{
    QFile rfile(file_path);
    bool ok = rfile.open(QIODevice::ReadOnly | QIODevice::Text);
    qDebug() << "rfile ok = " << ok;
    QTextStream r_stream(&rfile);
    r_stream.setCodec("UTF-8");
    all_file = r_stream.readAll();
    rfile.close();

    QFile wfile(file_path);
    ok = wfile.open(QIODevice::WriteOnly | QIODevice::Text);
    qDebug() << "wfile ok = " << ok;
    QTextStream w_stream(&wfile);
    w_stream.setCodec("UTF-8");
    all_file_list = all_file.split("\n");
    qDebug() << "file line: " << all_file_list.count();

    int start_line = -1;
    int insert_count = 0;
    bool node_flag = false;
    for (int i = 0; i < all_file_list.count(); i++) {
        if (all_file_list.at(i).contains("<Master_Sensitivity", Qt::CaseSensitive)) {
            node_flag = true;
            start_line = i + 2;
        } else if (all_file_list.at(i).contains("</Master_Sensitivity", Qt::CaseSensitive)) {
            node_flag = false;
        } else {
            //中间flag不变
        }

        if (node_flag) {
            //开始插入节点special
            if (all_file_list.at(i).contains(" High=") && !all_file_list.at(i).contains("special")) {
                QString tmp = all_file_list.at(i);
                tmp.insert(tmp.indexOf(" High="), QString::fromUtf8("special=\"0\" "));
                insert_count++;
                w_stream << tmp << '\n';
//                qDebug() << "seccuss to Write at: " << i;
            } else {
                w_stream << all_file_list.at(i) << '\n';
            }
            continue;
        }

        //其他数据不做处理直接写入
        if(i == all_file_list.count() - 1) {
            //最后一行不需要换行
            w_stream << all_file_list.at(i);
        } else {
            w_stream << all_file_list.at(i) << '\n';
        }
    }
    qDebug() << "insert_count: " << insert_count;
    wfile.close();
}

void MainWindow::on_pushButton_2_clicked()
{
    QFile rfile(file_path);
    bool ok = rfile.open(QIODevice::ReadOnly | QIODevice::Text);
    qDebug() << "rfile ok = " << ok;
    QTextStream r_stream(&rfile);
    r_stream.setCodec("UTF-8");
    all_file = r_stream.readAll();
    rfile.close();

    QFile wfile(file_path);
    ok = wfile.open(QIODevice::WriteOnly | QIODevice::Text);
    qDebug() << "wfile ok = " << ok;
    QTextStream w_stream(&wfile);
    w_stream.setCodec("UTF-8");
    all_file_list = all_file.split("\n");
    qDebug() << "file line: " << all_file_list.count();

    int start_line = -1;
    int insert_count = 0;
    bool node_flag = false;
    for (int i = 0; i < all_file_list.count(); i++) {
        if (all_file_list.at(i).contains("<Image_Sensitivity", Qt::CaseSensitive)) {
            node_flag = true;
            start_line = i + 2;
        } else if (all_file_list.at(i).contains("</Image_Sensitivity", Qt::CaseSensitive)) {
            node_flag = false;
        } else {
            //中间flag不变
        }

        if (node_flag) {
            //开始插入节点special
            if (all_file_list.at(i).contains(" High=") && !all_file_list.at(i).contains("special")) {
                QString tmp = all_file_list.at(i);
                tmp.insert(tmp.indexOf(" High="), QString::fromUtf8("special=\"0\" "));
                insert_count++;
                w_stream << tmp << '\n';
//                qDebug() << "seccuss to Write at: " << i;
            } else {
                w_stream << all_file_list.at(i) << '\n';
            }
            continue;
        }

        //其他数据不做处理直接写入
        if(i == all_file_list.count() - 1) {
            //最后一行不需要换行
            w_stream << all_file_list.at(i);
        } else {
            w_stream << all_file_list.at(i) << '\n';
        }
    }
    qDebug() << "insert_count: " << insert_count;
    wfile.close();
}
