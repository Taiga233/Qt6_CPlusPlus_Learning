#ifndef TEST_QABSTRACTSPINBOX_H
#define TEST_QABSTRACTSPINBOX_H

#include <QWidget>

QT_BEGIN_NAMESPACE
namespace Ui { class Test_QAbstractSpinBox; }
QT_END_NAMESPACE

class Test_QAbstractSpinBox : public QWidget
{
    Q_OBJECT

public:
    Test_QAbstractSpinBox(QWidget *parent = nullptr);
    ~Test_QAbstractSpinBox();

private slots:
    void on_pushButton_02_calculation_clicked();

    void on_pushButton_02_Dec_convert_clicked();

    void on_pushButton_03_Bin_convert_clicked();

    void on_pushButton_04_Hex_convert_clicked();

private:
    Ui::Test_QAbstractSpinBox *ui;
};
#endif // TEST_QABSTRACTSPINBOX_H
