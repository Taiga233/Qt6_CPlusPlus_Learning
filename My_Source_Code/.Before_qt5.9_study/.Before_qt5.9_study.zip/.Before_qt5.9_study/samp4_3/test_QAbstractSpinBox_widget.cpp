#include "test_QAbstractSpinBox_widget.h"
#include "ui_test_QAbstractSpinBox_widget.h"

Test_QAbstractSpinBox::Test_QAbstractSpinBox(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Test_QAbstractSpinBox)
{
    ui->setupUi(this);
    //“数量”和“单价”两个SpinBox的valueChanged()信号与on_btnCal_clicked()槽关联
    QObject::connect(ui->spinBox_01_count, SIGNAL(valueChanged(int)),
                     this, SLOT(on_pushButton_02_calculation_clicked()));
    QObject::connect(ui->doubleSpinBox_01_price, SIGNAL(valueChanged(double)),
                     this, SLOT(on_pushButton_02_calculation_clicked()));

    //将不同进制的spinBox的值改变的信号与对应的 转换成其他进制 的按钮关联
    QObject::connect(ui->spinBox_02_Dec, SIGNAL(valueChanged(int)),
                     this, SLOT(on_pushButton_02_Dec_convert_clicked()));
    QObject::connect(ui->spinBox_03_Bin, SIGNAL(valueChanged(int)),
                     this, SLOT(on_pushButton_03_Bin_convert_clicked()));
    QObject::connect(ui->spinBox_04_Hex, SIGNAL(valueChanged(int)),
                     this, SLOT(on_pushButton_04_Hex_convert_clicked()));
}

Test_QAbstractSpinBox::~Test_QAbstractSpinBox()
{
    delete ui;
}

//计算按钮的槽函数
void Test_QAbstractSpinBox::on_pushButton_02_calculation_clicked()
{
    int count = ui->spinBox_01_count->value();
    double price = ui->doubleSpinBox_01_price->value();
    double total = price * count;
    ui->doubleSpinBox_02_total->setValue(total);
}

//读取十进制，以其他进制显示
void Test_QAbstractSpinBox::on_pushButton_02_Dec_convert_clicked()
{
    int val;
    val = ui->spinBox_02_Dec->value();//读取十进制数
    ui->spinBox_03_Bin->setValue(val); //设置数值即可，自动以二进制显示
    ui->spinBox_04_Hex->setValue(val); //设置数值即可，自动以十六进制显示
}

//读取二进制，以其他进制显示
void Test_QAbstractSpinBox::on_pushButton_03_Bin_convert_clicked()
{
    int val=ui->spinBox_03_Bin->value();//读取spinBin里的二进制数，得到整数
    ui->spinBox_02_Dec->setValue(val);//设置数值即可，自动以十进制显示
    ui->spinBox_04_Hex->setValue(val);//设置数值即可，自动以十六进制显示
}

//读取十六进制，以其他进制显示
void Test_QAbstractSpinBox::on_pushButton_04_Hex_convert_clicked()
{
    int val;
    val=ui->spinBox_04_Hex->value();//读取 spinHex 里的十六进制数，得到整数
    ui->spinBox_02_Dec->setValue(val);//设置数值即可，自动以十进制显示
    ui->spinBox_03_Bin->setValue(val);//设置数值即可，自动以二进制显示
}
