#ifndef Q_WIDGET_MAINWINDOW_H
#define Q_WIDGET_MAINWINDOW_H

//#include <QtWidgets>
#include <QMainWindow>
#include <QLabel>
#include <QProgressBar>
#include <QFontComboBox>
#include <QSpinBox>

QT_BEGIN_NAMESPACE
namespace Ui { class Q_Widget_MainWindow; }
QT_END_NAMESPACE

class Q_Widget_MainWindow : public QMainWindow
{
    //不写默认为private的属性
    Q_OBJECT

public:
    Q_Widget_MainWindow(QWidget *parent = nullptr);
    ~Q_Widget_MainWindow();
    void show_all(int id);

private slots:
    //自定义的槽函数
    void on_spin_font_size_valueChanged(int FontSizeValue); //改变字体大小的SpinBox的响应
    void on_combo_font_currentIndexChanged(const QString &font_family); //FontCombobox的响应，选择字体名称

    //Qt自动创建的槽函数
    void on_action_format_bold_triggered(bool checked); //粗体Action

    void on_action_format_italic_triggered(bool checked); //斜体Action

    void on_action_format_underline_triggered(bool checked); //下划线Action

    void on_txtEdit_copyAvailable(bool b); //有文字可copy时更新cut,copy的Enable状态

    void on_txtEdit_selectionChanged(); //当前选择的文字发生变化,更新粗体、斜体、下划线3个action的checked状态

    void on_action_format_ToolBarLab_triggered(bool checked);//设置工具栏按钮样式

    void on_action_file_new_triggered(); //新建文件

    void on_action_file_open_triggered(); //打开文件

private:
    Ui::Q_Widget_MainWindow *ui; //设计界面的ui指针

    //创建其他组件
    QLabel *show_current_file_label; //状态栏里显示当前文件的Label
    QProgressBar *progress_bar; //状态栏上的进度条progress bar
    QSpinBox *spin_font_size; //字体大小的spin box
    QFontComboBox *combo_font; //字体名称的combo box

    void initUI(); //用代码实现的 UI 初始化函数
    /* initUI()函数用于创建这些界面组件，并添加到工具栏或状态栏中 */

    //关联信号与槽的初始化函数，该函数在Q_Widget_MainWindow的构造函数里调用
    void initSignalSlots();

    //其他成员变量
    QString current_file_name;

    //其他成员函数
    void update_current_file(QString file_path_name);
};
#endif // Q_WIDGET_MAINWINDOW_H
