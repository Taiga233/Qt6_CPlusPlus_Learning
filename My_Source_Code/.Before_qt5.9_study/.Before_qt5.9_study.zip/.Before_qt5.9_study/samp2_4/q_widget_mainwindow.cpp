#include "q_widget_mainwindow.h"
#include "ui_q_widget_mainwindow.h"

//#include <QFontDialog> //字体选择对话框
#include <QCoreApplication>
#include <QFileDialog>
#include <QFile>
#include <QTextStream>
#include <QTextCharFormat>

Q_Widget_MainWindow::Q_Widget_MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::Q_Widget_MainWindow)
{
    ui->setupUi(this);
    /* 注意：initUI()函数一定要在 ui->setupUi(this); 之后再调用，
     * 两行语句的先后顺序不能调换。
     * 因为 ui->setupUi(this); 实现了可视化设计的界面的创建，
     * initUI() 是在可视化创建的界面基础上添加的其他组件，
     * 所以必须在其后调用。
     */
    initUI();
    initSignalSlots();
}

Q_Widget_MainWindow::~Q_Widget_MainWindow()
{
    delete ui;
}

/* initUI()函数用于创建这些界面组件，并添加到工具栏或状态栏中；
 * 实现的代码如下：
 */
void Q_Widget_MainWindow::initUI()
{
    //状态栏上添加组件

    //显示当前文件名字的Label
    show_current_file_label = new QLabel;
    show_current_file_label->setMinimumWidth(150);
    show_current_file_label->setText("当前文件：");
    ui->statusbar->addWidget(show_current_file_label); //将显示当前文件的Label添加到状态栏

    //状态栏上的进度条progress bar
    progress_bar = new QProgressBar;
    progress_bar->setMinimumWidth(200);
    progress_bar->setMinimum(5);
    progress_bar->setMaximum(50);
    progress_bar->setValue(ui->txtEdit->font().pointSize());
    ui->statusbar->addWidget(progress_bar); //将进度条添加到状态栏

    //在工具栏上添加组件

    //设置文字大小的 spin box
    spin_font_size = new QSpinBox;
    spin_font_size->setMinimum(5);
    spin_font_size->setMaximum(50);
    spin_font_size->setValue(ui->txtEdit->font().pointSize());
    spin_font_size->setMinimumWidth(50);
    ui->toolBar->addWidget(new QLabel("字体大小：")); //添加一个固定的Label到工具栏
    ui->toolBar->addWidget(spin_font_size); //将spin box添加到工具栏
    //添加分隔条，仿照 ui_q_widget_mainwindow.h 中的添加分隔条
    ui->toolBar->addSeparator();
    //再添加一个固定的Label到工具栏
    ui->toolBar->addWidget(new QLabel(" 字体 "));
    //设置字体种类的 字体联合体box（QFontComboBox类型）
    combo_font = new QFontComboBox;
    combo_font->setMinimumWidth(150);
    ui->toolBar->addWidget(combo_font); //将font combo box 添加到工具栏

    setCentralWidget(ui->txtEdit); //设置文本编辑区居中
}

//设置字体为粗体的槽函数
void Q_Widget_MainWindow::on_action_format_bold_triggered(bool checked)
{
    QTextCharFormat fmt;
    fmt = ui->txtEdit->currentCharFormat();
    // 相当于调用ui->actFontBold->isChecked();读取Action的check状态
    if (checked) {
        fmt.setFontWeight(QFont::Bold);
    } else {
        fmt.setFontWeight(QFont::Normal);
    }
    //设置完之后就把fmt合并到ui->txtEdit中
    ui->txtEdit->mergeCurrentCharFormat(fmt);
}

//设置字体为斜体的槽函数
void Q_Widget_MainWindow::on_action_format_italic_triggered(bool checked)
{
    QTextCharFormat fmt;
    fmt = ui->txtEdit->currentCharFormat();
    fmt.setFontItalic(checked); //和设置字体粗体不一样
    ui->txtEdit->mergeCurrentCharFormat(fmt);
}

//设置字体有无下划线的槽函数
void Q_Widget_MainWindow::on_action_format_underline_triggered(bool checked)
{
    QTextCharFormat fmt;
    fmt = ui->txtEdit->currentCharFormat();
    fmt.setFontUnderline(checked);
    ui->txtEdit->mergeCurrentCharFormat(fmt); //合并
}

//copyAvailable(bool)信号在有内容可以被复制的时候发射，以下是对应的槽函数
void Q_Widget_MainWindow::on_txtEdit_copyAvailable(bool b)
{
    //更新cut，copy，paste的enabled属性
    ui->action_edit_cut->setEnabled(b);
    ui->action_edit_copy->setEnabled(b);
    ui->action_edit_paste->setEnabled(ui->txtEdit->canPaste()); //能否paste
}

//selectionChanged()信号在选择的文字发生变化时发射信号，以下是对应的槽函数
void Q_Widget_MainWindow::on_txtEdit_selectionChanged()
{
    QTextCharFormat fmt;
    fmt = ui->txtEdit->currentCharFormat(); //获取文字的格式
    ui->action_format_bold->setChecked(fmt.font().bold()); //检查是否有粗体
    ui->action_format_italic->setChecked(fmt.fontItalic()); //检查是否有斜体
    ui->action_format_underline->setChecked(fmt.fontUnderline()); //检查是否有下划线
}

//初始化关联 手工创建的组件和可视化设计中没有自带槽函数 的信号与槽的函数
void Q_Widget_MainWindow::initSignalSlots()
{
    //手工创建的组件

    //字体的字号
    connect(spin_font_size, SIGNAL(valueChanged(int)),
            this, SLOT(on_spin_font_size_valueChanged(int)));
    //字体的选择
    connect(combo_font, SIGNAL(currentIndexChanged(const QString &)),
            this, SLOT(on_combo_font_currentIndexChanged(const QString &)));
}

//改变字体字号的槽函数
void Q_Widget_MainWindow::on_spin_font_size_valueChanged(int FontSizeValue)
{
    QTextCharFormat fmt;
    fmt.setFontPointSize(FontSizeValue);
    ui->txtEdit->mergeCurrentCharFormat(fmt); //合并到ui的txtEdit文本编辑区
    progress_bar->setValue(FontSizeValue); //进度条的值为FontSizeValue
}

//改变字体族的槽函数
void Q_Widget_MainWindow::on_combo_font_currentIndexChanged(const QString &font_family)
{
    QTextCharFormat fmt;
    fmt.setFontFamily(font_family); //设置字体格式
    ui->txtEdit->mergeCurrentCharFormat(fmt); //合并到当前字体格式中去
}

//设置工具栏是否显示文字的槽函数
void Q_Widget_MainWindow::on_action_format_ToolBarLab_triggered(bool checked)
{
    if (checked) {
        //设置显示文字和图标，并且文字在图标的下面
        ui->toolBar->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);
    } else {
        //设置仅显示图标，不显示文字
        ui->toolBar->setToolButtonStyle(Qt::ToolButtonIconOnly);
    }
}

//更新当前文件名，并更新状态栏提示的函数
void Q_Widget_MainWindow::update_current_file(QString file_path_name)
{
    current_file_name = file_path_name;
    show_current_file_label->setText("当前文件：" + current_file_name);
}

//新建文件的槽函数
void Q_Widget_MainWindow::on_action_file_new_triggered()
{
    //暂时没有做完整的功能
    ui->txtEdit->clear(); //先清空当前的编辑区
    update_current_file(""); //然后再更新当前的文件
}

//打开文件的槽函数
void Q_Widget_MainWindow::on_action_file_open_triggered()
{
    QString temp_current_path = "", temp_current_filename = "";
    //获取应用程序当前的路径
    temp_current_path = QCoreApplication::applicationDirPath();

    //调用打开文件对话框打开一个文件
    temp_current_filename = QFileDialog::getOpenFileName
            (
                this,tr("打开一个文件"),temp_current_path,
                "C++程序文件(*.cpp);;H头文件(*.h);;文本文件(*.txt);;所有文件(*.*)"
             );

    if (!temp_current_filename.isEmpty()) {
        QFile aFile(temp_current_filename); //以文件方式读出
        if (aFile.open(QIODevice::ReadWrite | QIODevice::Text)) {
            QTextStream aStream(&aFile); //用文本流读文件

            while(!aStream.atEnd()) {
                ui->txtEdit->append(aStream.readLine()); //读取一个文本行
            }
            update_current_file(temp_current_filename); //更新状态栏显示
        }
        aFile.close(); //不要忘记关文件描述符
    }
}
