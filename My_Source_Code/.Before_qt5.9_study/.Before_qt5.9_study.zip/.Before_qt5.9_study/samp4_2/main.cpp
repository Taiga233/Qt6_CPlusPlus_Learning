#include "test_qstring_widget.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    TestQStringWidget w;
    w.show();
    return a.exec();
}
