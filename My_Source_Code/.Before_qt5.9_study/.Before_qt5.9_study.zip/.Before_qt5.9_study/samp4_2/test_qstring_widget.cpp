#include "test_qstring_widget.h"
#include "ui_test_qstring_widget.h"

TestQStringWidget::TestQStringWidget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::TestQStringWidget)
{
    ui->setupUi(this);
}

TestQStringWidget::~TestQStringWidget()
{
    delete ui;
}

//append()函数
void TestQStringWidget::on_pushButton_clicked()
{
     QString s1 = ui->comboBox->currentText();
     QString s2 = ui->comboBox_2->currentText();
     s1.append(s2);

     ui->lineEdit->setText(s1);
}

//prepend()函数
void TestQStringWidget::on_pushButton_3_clicked()
{
    QString s1 = ui->comboBox->currentText();
    QString s2 = ui->comboBox_2->currentText();
    s1.prepend(s2);

    ui->lineEdit->setText(s1);
}

//toUpper()函数
void TestQStringWidget::on_pushButton_8_clicked()
{
    QString s1 = ui->comboBox->currentText(), s2;
    s2 = s1.toUpper();

    ui->lineEdit->setText(s2);
}

//toLower()函数
void TestQStringWidget::on_pushButton_4_clicked()
{
    QString s1 = ui->comboBox->currentText(), s2;
    s2 = s1.toLower();

    ui->lineEdit->setText(s2);
}

//left()函数
void TestQStringWidget::on_pushButton_9_clicked()
{
    QString s1 = ui->comboBox->currentText();
    int val = ui->spinBox->value();
    s1 = s1.left(val);

    ui->lineEdit->setText(s1);
}

//right()函数
void TestQStringWidget::on_pushButton_5_clicked()
{
    QString s1 = ui->comboBox->currentText();
    int val = ui->spinBox->value();
//    s1 = s1.right(s1.size() - val - 1);
    s1 = s1.right(val);

    ui->lineEdit->setText(s1);
}

//section()函数
void TestQStringWidget::on_pushButton_6_clicked()
{
    QString s1 = ui->comboBox->currentText();
    QString s2 = ui->comboBox_2->currentText();
    QString s3;
//    QString s3 = s1.section('\\',2,2);
    int val = ui->spinBox->value();

    //静态compare()函数默认大小敏感
    if (QString::compare(s2, "\\", Qt::CaseInsensitive)) {
        s3 = s1.section('\\', val, val + 1);
    } else {
        s3 = s1.section(s2, val, val + 1);
    }
    //section()函数功能是从字符串中提取以sep作为分隔符，从start端到end端的字符串
    //会把该字符串分为几个部分，第一段的编号从0开始
    //注意 "\" 是转义字符，如果需要以"\"作为分隔，则sep为"\\"
    ui->lineEdit->setText(s3);
}

//simplified()函数
void TestQStringWidget::on_pushButton_11_clicked()
{
    QString s1 = ui->comboBox->currentText();
    ///simplified()函数不仅去掉字符串首位的空格，中间连续的空格也用一个空格替换
    s1 = s1.simplified();

    ui->lineEdit->setText(s1);
}

//trimmed()函数
void TestQStringWidget::on_pushButton_7_clicked()
{
    QString s1 = ui->comboBox->currentText();
    s1 = s1.trimmed(); //trimmed()函数去掉字符串首尾的空格

    ui->lineEdit->setText(s1);
}

//count()/length()函数
void TestQStringWidget::on_pushButton_14_clicked()
{
    QString s1 = ui->comboBox->currentText();
    int val = s1.count();
//    int val = s1.length();
    ui->spinBox->setValue(val);
    ui->label_3->setText("count() or length()");
}

//size()函数
void TestQStringWidget::on_pushButton_13_clicked()
{
    QString s1 = ui->comboBox->currentText();
    int val = s1.size();
    ui->spinBox->setValue(val);
    ui->label_3->setText("size()");
}

//indexOf()函数
void TestQStringWidget::on_pushButton_12_clicked()
{
    QString s1 = ui->comboBox->currentText();
    QString s2 = ui->comboBox_2->currentText();
    int position = s1.indexOf(s2);
    //indexOf()函数的原型为：
    //int QString::indexOf(QLatin1String str, int from = 0, Qt::CaseSensitivity cs = Qt::CaseSensitive) const
    //该函数功能是在！自身字符串！内查找参数字符串str出现的位置，参数from是开始查找的位置，默认从0开始，若没找到返回-1
    //Qt::CaseSensitivity cs参数指定是否区分大小写，默认大小写敏感
    //If from is -1, the search starts at the last character;
    //if it is -2, at the next to last character and so on.

    ui->spinBox->setValue(position);
    ui->label_3->setText("indexOf()");
}

//lastIndexOf()函数
void TestQStringWidget::on_pushButton_10_clicked()
{
    QString s1 = ui->comboBox->currentText();
    QString s2 = ui->comboBox_2->currentText();
    int position = s1.lastIndexOf(s2);
    //lastIndexOf()函数则是在自身字符串内查找某个字符串！最后！出现的位置
    //int QString::lastIndexOf(const QString &str, int from = -1, Qt::CaseSensitivity cs = Qt::CaseSensitive) const

    ui->spinBox->setValue(position);
    ui->label_3->setText("lastIndexOf()");
}

//startsWith()函数
void TestQStringWidget::on_pushButton_2_clicked()
{
    QString s1 = ui->comboBox->currentText();
    QString s2 = ui->comboBox_2->currentText();

    ui->checkBox->setChecked(s1.startsWith(s2));
    //startsWith()函数判断自身是否以某个字符串开头，默认为大小写不敏感
    ui->checkBox->setText("startsWith()");
    ui->checkBox->sizeHint();
}

//endsWith()函数
void TestQStringWidget::on_pushButton_15_clicked()
{
    QString s1 = ui->comboBox->currentText();
    QString s2 = ui->comboBox_2->currentText();

    ui->checkBox->setChecked(s1.endsWith(s2));
    //startsWith()函数判断自身是否以某个字符串结尾，默认为大小写不敏感
    ui->checkBox->setText("endsWith()");
    ui->checkBox->sizeHint();
}

//contains()函数
void TestQStringWidget::on_pushButton_16_clicked()
{
    QString s1 = ui->comboBox->currentText();
    QString s2 = ui->comboBox_2->currentText();

    ui->checkBox->setChecked(s1.contains(s2));
    ui->checkBox->setText("contains() /*sizeHint()*/");
    /*这个属性所保存的 QSize 类型的值是一个被推荐给窗口或其它组件（为了方便下面统称为widget）的尺寸，
     * 也就是说一个 widget 该有多大，它的一个参考来源就是这个 sizeHint 属性的值，
     * 而这个值由 sizeHint() 函数来确定。*/
    ui->checkBox->sizeHint(); //sizeHint() 会返回一个被推荐的尺寸
}

//isNull()函数
void TestQStringWidget::on_pushButton_17_clicked()
{
    QString s1 = ui->comboBox->currentText();
    bool check_val = s1.isNull();
    //QString只要复制，就在字符串的末尾自动加上"\0"，所以空串 "" isNull()返回false

    ui->checkBox->setChecked(check_val);
    ui->checkBox->setText("isNull()");
    ui->checkBox->sizeHint();
}

//isEmpty()函数
void TestQStringWidget::on_pushButton_18_clicked()
{
    QString s1 = ui->comboBox->currentText();
    bool check_val = s1.isEmpty();
    //判断字符串的！内容！是否为空，常用isEmpty()

    ui->checkBox->setChecked(check_val);
    ui->checkBox->setText("isEmpty()");
    ui->checkBox->sizeHint();
}
